import { type ReactNode } from 'react';
export interface InlinePanelProps {
    title: ReactNode;
    /** Uncontrolled initial state. */
    defaultOpen?: boolean;
    /** Controlled state — pair with onToggle. */
    open?: boolean;
    onToggle?: (open: boolean) => void;
    /** Extra controls rendered at the right end of the header. */
    actions?: ReactNode;
    children: ReactNode;
    className?: string;
}
/**
 * A collapsible section for stacking inside panels — the inline cousin of a
 * dock panel. The body animates shut via the grid-rows trick, so no measuring.
 */
export declare function InlinePanel({ title, defaultOpen, open, onToggle, actions, children, className, }: InlinePanelProps): import("react").JSX.Element;
