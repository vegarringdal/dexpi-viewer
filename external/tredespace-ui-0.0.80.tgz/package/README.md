# @tredespace/ui

The TreDeSpace component library: the widgets, dialogs, tooltips, hotkeys
registry, and dockable panel shell the TreDeSpace viewer's UI is built from.
Live gallery with usage snippets and props docs: `/docs/widgets.html` on any
TreDeSpace deployment.

Compiled ESM + TypeScript declarations. A bundler (Vite, webpack, …) is
required — internal imports are extensionless and CSS is imported from JS.

## Install (from the downloaded tarball)

```json
"dependencies": {
  "@tredespace/ui": "file:./libs/tredespace-ui-0.0.80.tgz"
}
```

### What you need alongside it

- **React 19** — `react` and `react-dom` >= 19 are peer dependencies
  (npm 7+ installs them automatically if absent; an older React in your
  project is a conflict).
- **Tailwind CSS v4 in your build** — the widgets style themselves with
  Tailwind utilities, and a build tool can't come bundled inside a package:
  `npm i -D tailwindcss @tailwindcss/vite` (or `@tailwindcss/postcss`
  for non-Vite setups), then see the styling section below.

Everything else (`lit-html`, `@tabler/icons-react`, `clsx`,
`tailwind-merge`) is a regular dependency and installs automatically with
the package — no action needed.

## Styling (Tailwind v4)

The widgets style themselves with Tailwind utility classes, so your Tailwind
build must scan this package (node_modules is not scanned by default), and the
library's theme/scrollbar stylesheet must be imported:

```css
@import "tailwindcss";
@import "@tredespace/ui/styles.css";
@source "../node_modules/@tredespace/ui";
```

Theming: the library reads Tailwind's `--color-*` variables and ships a light
remap keyed by `data-theme="light"` on `<html>` (dark is the default). The
dock chrome (`dockable`) carries its own plain CSS with fallback colors and
works even without Tailwind.

## Entry points

```ts
import { Button, Select, initTooltips } from '@tredespace/ui/widgets';
import { DockView, definePanel, split, tabs, useDockManager } from '@tredespace/ui/dockable';
import { hotkeysActions } from '@tredespace/ui/hotkeys';
```

Call `initTooltips()` once at startup to enable the `data-tooltip`
attribute tooltips (and hotkey-combo footers via `data-shortcut`).
