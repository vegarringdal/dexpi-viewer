import type { DockManager } from './DockManager';
/** Mounts the dock into the DOM. Everything inside is managed by lit-html. */
export declare function DockView({ manager, className }: {
    manager: DockManager;
    className?: string;
}): import("react").JSX.Element;
