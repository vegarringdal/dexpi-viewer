import { jsx as _jsx } from "react/jsx-runtime";
import { useLayoutEffect, useRef } from 'react';
/** Mounts the dock into the DOM. Everything inside is managed by lit-html. */
export function DockView({ manager, className }) {
    const ref = useRef(null);
    useLayoutEffect(() => {
        const el = ref.current;
        if (!el) {
            return;
        }
        manager.mount(el);
        return () => manager.unmount();
    }, [manager]);
    return _jsx("div", { ref: ref, className: className });
}
