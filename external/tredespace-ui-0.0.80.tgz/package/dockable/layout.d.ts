import type { DropZone, LayoutNode, Size, SplitNode, TabsNode } from './types';
export declare const uid: (prefix?: string) => string;
export declare const tabs: (panels: string[], extra?: Partial<TabsNode>) => TabsNode;
export declare const split: (direction: "row" | "column", children: LayoutNode[], sizes?: number[], extra?: Partial<SplitNode>) => SplitNode;
export declare function walk(node: LayoutNode, fn: (n: LayoutNode, parent: SplitNode | null) => void, parent?: SplitNode | null): void;
export declare function findNode(root: LayoutNode, id: string): LayoutNode | null;
export declare function findParent(root: LayoutNode, id: string): SplitNode | null;
export declare function findTabsWithPanel(root: LayoutNode, panelId: string): TabsNode | null;
export declare function allPanels(root: LayoutNode): string[];
/** True if the node or any ancestor is locked. */
export declare function isLocked(root: LayoutNode, id: string): boolean;
/**
 * Drop a panel out of the tree, pruning empty tabs and collapsing single-child
 * splits. Returns the new root (never null — an empty tabs node survives).
 */
export declare function removePanel(root: LayoutNode, panelId: string): LayoutNode;
/** Replace one node with another, by id. */
export declare function replaceNode(root: LayoutNode, targetId: string, make: (n: LayoutNode) => LayoutNode): LayoutNode;
/** Add a panel to an existing tabs node (optionally at an index) and focus it. */
export declare function insertIntoTabs(root: LayoutNode, tabsId: string, panelId: string, index?: number): LayoutNode;
export type SplitZone = Exclude<DropZone, 'center' | 'float'>;
/** Split `targetId` and put `panelId` on the given side of it. */
export declare function splitWithPanel(root: LayoutNode, targetId: string, panelId: string, zone: SplitZone): LayoutNode;
export interface MeasureEnv {
    headerHeight: number;
    splitterSize: number;
    /** Effective (definition + runtime override) minimum for a panel. */
    panelMin(panelId: string): Size;
    /** MEASURED height of a tabs node's strip, when the host tracks it: a strip
     *  whose tabs wrapped onto extra rows is taller than `headerHeight`, and
     *  folding the real height in here makes the GROUP grow instead of the extra
     *  rows eating into the panel body. Falls back to `headerHeight`. */
    stripHeight?(nodeId: string): number;
}
/** Smallest box a node can be squeezed into, in px. */
export declare function measureMin(node: LayoutNode, env: MeasureEnv): Size;
/** Which zone of a rect a point falls into. Center = drop as a tab. */
export declare function zoneAt(rect: DOMRect, x: number, y: number, edge?: number): DropZone;
export declare function cloneLayout<T extends LayoutNode>(node: T): T;
/** True when a tree holds no panels at all. */
export declare function isEmpty(node: LayoutNode): boolean;
/**
 * Re-insert locked "furniture" (toolbars, ribbon strips) that a restored layout
 * has lost, using `template` (the pristine default) as the source of truth.
 *
 * A locked node can't be closed, floated or dragged out by the user, so its
 * absence from a saved layout is always breakage — an older snapshot taken
 * before a ribbon existed, or one that somehow dropped the strip. Restoring it
 * blindly then leaves furniture missing until the user hits Reset. This heals
 * two cases without disturbing the user's own docking, sizes or tab order:
 *   • a surviving furniture node that lost some pinned panels (e.g. ribbons
 *     added in a newer build than the save) — the missing ones are spliced back
 *     in template order, active tab untouched;
 *   • a furniture node gone entirely — its template copy is wrapped back on at
 *     the edge where the template kept it, so it stays outermost.
 * Returns the healed root; a layout that already has all its furniture is
 * returned structurally unchanged.
 */
export declare function healFurniture(root: LayoutNode, template: LayoutNode): LayoutNode;
/**
 * The dockable area: the deepest unlocked node that still contains every
 * unlocked leaf. With a locked toolbar on top, this is everything below it —
 * so "dock top" lands under the toolbar, not above it.
 */
export declare function dockRegion(root: LayoutNode): LayoutNode;
/**
 * Dock a panel against one edge of a region, flattening into it when possible.
 * Locked children (toolbar-style furniture) always stay outermost: the panel
 * lands just inside them, never beside or beyond them.
 */
export declare function dockAtEdge(root: LayoutNode, regionId: string, panelId: string, zone: SplitZone): LayoutNode;
/**
 * Stack a panel underneath another. If the target already sits in a column,
 * the new panel joins that column as a sibling rather than nesting a split
 * inside it — so dragging onto the bottom of the last panel just adds a row.
 */
export declare function dockBelow(root: LayoutNode, targetId: string, panelId: string): LayoutNode;
/**
 * True when nothing in this subtree is showing content. A column whose panels
 * are all collapsed has nothing to display, so it should give up its width to
 * its siblings and become a rail — not sit there as a wide stack of strips.
 */
/**
 * Structural normalization: hoist single-child splits and inline same-axis
 * child splits into their parent (weights rescaled so rendered proportions
 * are unchanged). Drag-dock operations nest liberally; without this a
 * visually flat PANEL1|PANEL2|PANEL3 row can secretly be a split-in-a-split,
 * and divider cascades — which walk REAL siblings — stop at the hidden
 * boundary. Locked or fixed-size sub-splits are left intact (their scope
 * carries meaning).
 */
export declare function normalizeLayout(node: LayoutNode): LayoutNode;
export declare function isCollapsedTree(node: LayoutNode): boolean;
