import { type ComponentType } from 'react';
import { DockManager } from './DockManager';
import type { DockManagerOptions, PanelContext, PanelDefinition, PanelRenderer } from './types';
/** The dock context for the panel this component is rendered inside. */
export declare function usePanelContext(): PanelContext;
/** True while this panel lives in a floating window. */
export declare function useIsFloating(manager: DockManager, panelId: string): boolean;
/** Declare how small this panel's content may be squeezed, in px. */
export declare function useMinSize(width?: number, height?: number): void;
/** Rename the tab from inside the panel. */
export declare function usePanelTitle(title: string): void;
/**
 * Wrap a React component as panel content. The React root is created once and
 * survives docking, tab switching and re-splitting — the dock only reparents
 * the host element, it never re-creates it.
 */
export declare function reactPanel(Component: ComponentType<{
    ctx: PanelContext;
}>): PanelRenderer;
/** Define a panel whose content is a React component. */
export declare function definePanel(def: Omit<PanelDefinition, 'render'> & {
    component: ComponentType<{
        ctx: PanelContext;
    }>;
}): PanelDefinition;
/** Create a DockManager that lives for the lifetime of the component. */
export declare function useDockManager(makeOptions: () => DockManagerOptions): DockManager;
/**
 * Re-render the calling component whenever the layout changes — panels opening,
 * closing, moving, floating, resizing. Returns the version counter, which is a
 * stable snapshot (the tree itself is mutated in place during drags).
 */
export declare function useDockLayout(manager: DockManager): number;
export { DockView } from './DockView';
export { PanelBody } from './PanelBody';
