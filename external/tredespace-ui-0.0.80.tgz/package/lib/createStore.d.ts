/**
 * A tiny global store — the pattern every *.state.ts file builds on.
 * No external lib: React's useSyncExternalStore does all the heavy lifting.
 *
 *   const ui = createStore({ sidebarOpen: false });
 *   ui.set({ sidebarOpen: !ui.get().sidebarOpen });   // flip a bool → every user re-renders
 *   const { sidebarOpen } = ui.use();                 // inside any component
 *
 * Works outside React too (plain DOM, three.js, timers): subscribe() directly.
 */
/** The store handle createStore returns — for code parameterized over a store
 *  instance (e.g. the Set Color editor bound to global vs viewpoint rules). */
export type Store<T extends object> = ReturnType<typeof createStore<T>>;
export declare function createStore<T extends object>(initial: T): {
    get: () => T;
    subscribe: (fn: () => void) => () => undefined;
    set(patch: Partial<T> | ((prev: T) => Partial<T>)): void;
    use(): T;
};
