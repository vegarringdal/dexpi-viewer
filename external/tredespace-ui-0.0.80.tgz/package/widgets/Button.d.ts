import type { MouseEvent as ReactMouseEvent, ReactNode } from 'react';
export interface ButtonProps {
    children?: ReactNode;
    /** Optional leading icon (locked to 14×14). */
    icon?: ReactNode;
    /** The click event is passed so handlers can read modifiers (e.g. Alt). */
    onClick?: (e: ReactMouseEvent) => void;
    disabled?: boolean;
    /** Highlighted / selected look. */
    active?: boolean;
    /** Static display chip — no hover, no pointer, not focusable. Use for
     *  read-only values that share the button look (e.g. a shortcut combo). */
    readOnly?: boolean;
    /** Square icon-only button (h=w), for compact actions like a reset ✕. */
    iconOnly?: boolean;
    title?: string;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    className?: string;
}
/** The app's button. Read-only mode renders a non-interactive chip that keeps
 *  the same box so buttons and displayed values line up. */
export declare function Button({ children, icon, onClick, disabled, active, readOnly, iconOnly, title, tooltip, shortcut, className, }: ButtonProps): import("react").JSX.Element;
