import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { InfoButton } from './InfoButton';
/** A single on/off checkbox in the settings-panel visual language — the
 *  standalone sibling of a RadioGroup row. */
export function Checkbox({ checked, onChange, label, hint, info, disabled = false, tooltip, shortcut, className = '', }) {
    return (_jsxs("div", { className: `flex items-center gap-2 ${className}`, children: [_jsxs("label", { className: `flex items-center gap-2 text-slate-300 text-xs ${disabled ? 'opacity-50' : 'cursor-pointer'}`, "data-tooltip": tooltip, "data-shortcut": shortcut, children: [_jsx("input", { type: "checkbox", checked: checked, disabled: disabled, onChange: (e) => onChange(e.target.checked) }), label, info == null && hint && _jsxs("span", { className: "text-slate-500", children: ["\u2014 ", hint] })] }), info != null && _jsx(InfoButton, { children: info })] }));
}
