import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconChevronDown, IconChevronRight } from '@tabler/icons-react';
import { useState } from 'react';
import { cn } from '../lib/cn';
import { InfoButton } from './InfoButton';
/** A titled section that collapses. Same header look as the Shortcuts panel
 *  groups; used to organise long settings tabs. */
export function Collapsible({ title, aside, info, defaultOpen = true, children, className = '', fill = false, fillMinClass, }) {
    const [open, setOpen] = useState(defaultOpen);
    const fillClasses = cn('min-h-0 flex-1 overflow-hidden', fillMinClass);
    return (_jsxs("div", { className: cn('flex flex-col border border-slate-800', fill && open && fillClasses, className), children: [_jsxs("div", { className: "flex w-full items-center gap-1 bg-slate-800 px-2 py-1 text-slate-200 text-xs hover:bg-slate-700", children: [_jsxs("button", { type: "button", className: "flex min-w-0 flex-1 items-center gap-1 text-left font-medium", onClick: () => setOpen((o) => !o), children: [open ? (_jsx(IconChevronDown, { size: 14, className: "shrink-0" })) : (_jsx(IconChevronRight, { size: 14, className: "shrink-0" })), title] }), aside != null && _jsx("span", { className: "text-slate-500", children: aside }), info != null && _jsx(InfoButton, { children: info })] }), open && _jsx("div", { className: cn('flex flex-col gap-2 p-2', fill && fillClasses), children: children })] }));
}
