import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconAlertTriangle } from '@tabler/icons-react';
import { Modal, TitleBar } from './Modal';
/** Pure error dialog — props only, no store coupling. */
export function ErrorDialogCore({ title, message, onDismiss, z = 2010 }) {
    return (_jsx(Modal, { z: z, children: _jsxs("div", { role: "alertdialog", "aria-modal": "true", className: "w-80 border border-slate-600 bg-slate-900 shadow-black/50 shadow-xl", children: [_jsx(TitleBar, { icon: _jsx(IconAlertTriangle, { size: 16, className: "shrink-0 text-amber-400" }), children: title }), _jsx("div", { className: "px-3 py-4 text-xs leading-relaxed", children: message }), _jsx("div", { className: "flex justify-end border-slate-800 border-t px-3 py-2", children: _jsx("button", { type: "button", className: "cursor-pointer border border-slate-600 bg-slate-800 px-4 py-1 text-slate-200 text-xs hover:bg-slate-700", onClick: onDismiss, children: "OK" }) })] }) }));
}
