import { type ReactNode } from 'react';
export interface InlinePanelProps {
    title: ReactNode;
    /** Uncontrolled initial state. */
    defaultOpen?: boolean;
    /** Controlled state — pair with onToggle. */
    open?: boolean;
    onToggle?: (open: boolean) => void;
    /** Extra controls rendered at the right end of the header. */
    actions?: ReactNode;
    /** The header text is UPPERCASED by default (the dock-panel look); set
     *  false to show the title exactly as written. */
    titleUppercase?: boolean;
    /** Classes for the header text — merged over the default styling, so
     *  `titleClassName="text-sm normal-case text-sky-300"` restyles it without
     *  replacing the widget. Pass a node as `title` for full control. */
    titleClassName?: string;
    children: ReactNode;
    className?: string;
}
/**
 * A collapsible section for stacking inside panels — the inline cousin of a
 * dock panel. The body animates shut via the grid-rows trick, so no measuring.
 */
export declare function InlinePanel({ title, defaultOpen, open, onToggle, actions, titleUppercase, titleClassName, children, className, }: InlinePanelProps): import("react").JSX.Element;
