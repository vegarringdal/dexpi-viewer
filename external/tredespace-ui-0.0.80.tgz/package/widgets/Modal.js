import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { createPortal } from 'react-dom';
/** Shared modal shell: dimmed backdrop + centred window at the given layer. */
export function Modal({ z, children, onKeyDown }) {
    return createPortal(_jsx("div", { className: "fixed inset-0 flex items-center justify-center bg-black/40 text-slate-200", style: { zIndex: z }, onKeyDown: onKeyDown, children: children }), document.body);
}
export function TitleBar({ icon, children }) {
    return (_jsxs("div", { className: "flex items-center gap-2 border-slate-800 border-b bg-slate-800 px-3 py-2 font-semibold text-xs", children: [icon, children] }));
}
