import type { ReactNode } from 'react';
import type { PopoverAnchor } from './usePopoverAnchor';
export interface PickerFieldProps {
    open: boolean;
    /** Leading field icon (locked to 14×14 by the caller). */
    icon: ReactNode;
    /** Current display text, or null to show the placeholder. */
    value: string | null;
    placeholder: string;
    /** aria-label of the hover-revealed clear ×. */
    clearLabel: string;
    disabled: boolean;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    onToggle: () => void;
    onClear: () => void;
}
/** Select-style trigger: icon + value text + hover-revealed clear ×. */
export declare function PickerField({ open, icon, value, placeholder, clearLabel, disabled, tooltip, shortcut, onToggle, onClear, }: PickerFieldProps): import("react").JSX.Element;
export interface PickerPopoverProps {
    anchor: PopoverAnchor;
    /** Popover width in px — used to clamp the left edge into the viewport. */
    width: number;
    children: ReactNode;
}
/** Body-portaled popover box anchored under (or above) the trigger. */
export declare function PickerPopover({ anchor, width, children }: PickerPopoverProps): import("react").ReactPortal;
