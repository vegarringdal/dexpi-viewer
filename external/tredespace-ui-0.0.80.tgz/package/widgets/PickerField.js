import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { createPortal } from 'react-dom';
import { pickerPopCls, pickerTriggerCls } from './fieldChrome';
/** Select-style trigger: icon + value text + hover-revealed clear ×. */
export function PickerField({ open, icon, value, placeholder, clearLabel, disabled, tooltip, shortcut, onToggle, onClear, }) {
    return (_jsxs("button", { type: "button", disabled: disabled, "aria-haspopup": "dialog", "aria-expanded": open, "data-tooltip": tooltip, "data-shortcut": shortcut, className: pickerTriggerCls(open, disabled), onClick: onToggle, children: [icon, value != null ? (_jsx("span", { className: "min-w-0 flex-1 truncate", children: value })) : (_jsx("span", { className: "min-w-0 flex-1 truncate text-slate-400", children: placeholder })), value != null && !disabled && (_jsx("span", { role: "button", "aria-label": clearLabel, title: "Clear", className: "shrink-0 cursor-pointer px-0.5 text-slate-400 leading-none opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100", onPointerDown: (e) => e.stopPropagation(), onClick: (e) => {
                    e.stopPropagation();
                    onClear();
                }, children: "\u00D7" }))] }));
}
/** Body-portaled popover box anchored under (or above) the trigger. */
export function PickerPopover({ anchor, width, children }) {
    return createPortal(_jsx("div", { ref: anchor.popRef, className: pickerPopCls, style: {
            left: Math.max(4, Math.min(anchor.pos.left, window.innerWidth - width - 4)),
            top: anchor.pos.up ? undefined : anchor.pos.top + 4,
            bottom: anchor.pos.up ? window.innerHeight - anchor.pos.top + 4 : undefined,
        }, children: children }), document.body);
}
