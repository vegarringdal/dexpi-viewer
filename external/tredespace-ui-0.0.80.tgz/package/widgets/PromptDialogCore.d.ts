export interface PromptDialogCoreProps {
    title: string;
    message: string;
    value: string;
    okLabel: string;
    cancelLabel?: string;
    onChange: (value: string) => void;
    /** Called with true for OK/Enter, false for Cancel/Escape. */
    onResult: (ok: boolean) => void;
    z?: number;
}
/** Pure one-line text-input dialog — props only, no store coupling; the caller
 *  owns the controlled input value. */
export declare function PromptDialogCore({ title, message, value, okLabel, cancelLabel, onChange, onResult, z, }: PromptDialogCoreProps): import("react").JSX.Element;
