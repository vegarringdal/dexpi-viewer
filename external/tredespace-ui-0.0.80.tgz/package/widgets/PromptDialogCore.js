import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconPencil } from '@tabler/icons-react';
import { Modal, TitleBar } from './Modal';
/** Pure one-line text-input dialog — props only, no store coupling; the caller
 *  owns the controlled input value. */
export function PromptDialogCore({ title, message, value, okLabel, cancelLabel = 'Cancel', onChange, onResult, z = 2000, }) {
    return (_jsx(Modal, { z: z, onKeyDown: (e) => e.key === 'Escape' && onResult(false), children: _jsxs("div", { role: "dialog", "aria-modal": "true", className: "w-80 border border-slate-600 bg-slate-900 shadow-black/50 shadow-xl", children: [_jsx(TitleBar, { icon: _jsx(IconPencil, { size: 16, className: "shrink-0 text-blue-400" }), children: title }), _jsxs("div", { className: "flex flex-col gap-2 px-3 py-4 text-xs leading-relaxed", children: [_jsx("span", { children: message }), _jsx("input", { 
                            // biome-ignore lint/a11y/noAutofocus: single-field dialog — focus is the point
                            autoFocus: true, value: value, className: "w-full border border-slate-700 bg-slate-950 px-2 py-1 text-slate-200 text-xs outline-none focus:border-blue-400", onChange: (e) => onChange(e.target.value), onKeyDown: (e) => {
                                if (e.key === 'Enter') {
                                    onResult(true);
                                }
                            } })] }), _jsxs("div", { className: "flex justify-end gap-1.5 border-slate-800 border-t px-3 py-2", children: [_jsx("button", { type: "button", className: "cursor-pointer border border-slate-600 bg-transparent px-4 py-1 text-slate-300 text-xs hover:bg-slate-800 hover:text-slate-200", onClick: () => onResult(false), children: cancelLabel }), _jsx("button", { type: "button", className: "cursor-pointer border border-blue-400 bg-blue-950 px-4 py-1 text-blue-100 text-xs hover:bg-blue-900", onClick: () => onResult(true), children: okLabel })] })] }) }));
}
