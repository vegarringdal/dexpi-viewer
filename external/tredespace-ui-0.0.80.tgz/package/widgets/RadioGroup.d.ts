import type { ReactNode } from 'react';
export interface RadioOption {
    value: string;
    label: string;
    /** Small dimmed note after the label. */
    hint?: string;
    /** Longer explanation, shown behind an info icon after the label (replaces
     *  the inline hint when set) — keeps the row short. */
    info?: ReactNode;
    /** Hotkey id (data-shortcut) for this option. */
    shortcut?: string;
}
export interface RadioGroupProps {
    value: string;
    options: RadioOption[];
    onChange: (value: string) => void;
    disabled?: boolean;
    className?: string;
}
/** Mutually-exclusive options rendered as square checkboxes (only one true) —
 *  same visual language as the settings checkboxes, and each option carries a
 *  data-shortcut so it can be bound to a hotkey. */
export declare function RadioGroup({ value, options, onChange, disabled, className }: RadioGroupProps): import("react").JSX.Element;
