/**
 * Attribute-driven tooltips: put `data-tooltip="text"` on any element and it
 * gets a styled tooltip — no wrapper component, works in React and plain DOM
 * alike. Multi-line via real newlines or a literal "\n" in the attribute.
 *
 * One document-level listener drives everything; call initTooltips() once
 * (App does) and forget about it. The bubble prefers sitting above the
 * element, flips below when there is no room, and clamps to the viewport.
 */
export declare function initTooltips(): () => void;
