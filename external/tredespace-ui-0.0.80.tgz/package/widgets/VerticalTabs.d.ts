import { type ReactNode } from 'react';
export interface VerticalTab {
    id: string;
    /** Omit for an icon-only tab — pair it with `tooltip`. */
    label?: string;
    icon?: ReactNode;
    /** Styled tooltip (data-tooltip); supports "\n" for multiple lines. */
    tooltip?: string;
    content: ReactNode;
}
export interface VerticalTabsProps {
    tabs: VerticalTab[];
    /** Controlled active tab — pair with onChange. */
    value?: string;
    defaultValue?: string;
    onChange?: (id: string) => void;
    /** Which side the strip sits on. */
    side?: 'left' | 'right';
    className?: string;
}
/** A tab strip that runs down the side instead of across the top. */
export declare function VerticalTabs({ tabs, value, defaultValue, onChange, side, className, }: VerticalTabsProps): import("react").JSX.Element;
