import type { RefObject } from 'react';
import { type HSV, type RGB } from './colorConversions';
/** The picker popover body: SV area, hue bar, hex/RGB entry, quick swatches. */
export declare function ColorSelectPopover({ hsv, rgb, hex, apply, quickSwatches, pos, popRef, svRef, hueRef, }: {
    hsv: HSV;
    rgb: RGB;
    hex: string;
    apply: (next: HSV) => void;
    quickSwatches: string[];
    pos: {
        left: number;
        top: number;
        up: boolean;
    };
    popRef: RefObject<HTMLDivElement | null>;
    svRef: RefObject<HTMLDivElement | null>;
    hueRef: RefObject<HTMLDivElement | null>;
}): import("react").JSX.Element;
