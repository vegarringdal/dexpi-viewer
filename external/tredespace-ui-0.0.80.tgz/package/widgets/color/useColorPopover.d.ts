import { type RefObject } from 'react';
/** Popover plumbing shared with the trigger: close on outside pointer press,
 *  and place the fixed popover under (or above) the trigger, clamped to the
 *  viewport's right edge. */
export declare function useColorPopover(open: boolean, setOpen: (o: boolean) => void, rootRef: RefObject<HTMLDivElement | null>, popRef: RefObject<HTMLDivElement | null>): {
    left: number;
    top: number;
    up: boolean;
};
