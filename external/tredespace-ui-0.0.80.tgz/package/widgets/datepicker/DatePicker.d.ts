/** A day span; either edge may still be unset while the user is picking. */
export type DateRange = Readonly<{
    start: string | null;
    end: string | null;
}>;
interface DatePickerBaseProps {
    /** Earliest / latest pickable day (ISO `yyyy-mm-dd`, inclusive). */
    min?: string;
    max?: string;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    /** Styled tooltip (data-tooltip) on the field. */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
}
export interface SingleDatePickerProps extends DatePickerBaseProps {
    range?: false;
    /** Selected day as ISO `yyyy-mm-dd`, or null when empty. */
    value: string | null;
    /** Receives the picked day, or null when cleared. */
    onChange: (value: string | null) => void;
}
export interface RangeDatePickerProps extends DatePickerBaseProps {
    /** Range mode: the first click picks the start, the second the end
     *  (auto-swapped when clicked backwards); hovering previews the span. */
    range: true;
    value: DateRange;
    onChange: (value: DateRange) => void;
}
export type DatePickerProps = SingleDatePickerProps | RangeDatePickerProps;
/**
 * A compact calendar field in the dock's visual language: Monday-first weeks
 * with an ISO 8601 week-number column, single day or day range. Values cross
 * the API as ISO `yyyy-mm-dd` strings (never Date objects), so timezones
 * cannot shift days.
 */
export declare function DatePicker(props: DatePickerProps): import("react").JSX.Element;
export {};
