export type DateParts = Readonly<{
    y: number;
    m: number;
    d: number;
}>;
/** Parse `yyyy-mm-dd`; null when malformed or not a real calendar day. */
export declare function parseIsoDate(iso: string | null | undefined): DateParts | null;
export declare function formatIsoDate(p: DateParts): string;
/** Today in the user's local timezone (the one place local time is read). */
export declare function todayParts(): DateParts;
/**
 * ISO 8601 week number, 1–53. Weeks start Monday; week 1 is the week
 * containing the year's first Thursday (equivalently, the one containing
 * January 4th), so edge days can belong to week 52/53 of the previous year
 * or week 1 of the next.
 */
export declare function isoWeek(p: DateParts): number;
export type GridDay = Readonly<{
    parts: DateParts;
    iso: string;
    inMonth: boolean;
}>;
export type GridWeek = Readonly<{
    week: number;
    days: readonly GridDay[];
}>;
/**
 * The 6 Monday-first weeks covering month `m` of year `y` (fixed 6 rows so
 * the calendar never changes height), each row tagged with its ISO week
 * number; leading/trailing days of the neighbour months are marked.
 */
export declare function monthGrid(y: number, m: number): readonly GridWeek[];
/** Month arithmetic that carries across year boundaries. */
export declare function addMonths(y: number, m: number, delta: number): {
    y: number;
    m: number;
};
