import type { ReactNode } from 'react';
/** The in-field clear button (shared by TextInput/TextArea). Floats over the
 *  right edge; clears content by default, or runs `onClear` when given. */
export declare function ClearButton({ onClick, className }: {
    onClick: () => void;
    className?: string;
}): import("react").JSX.Element;
export interface LabelledProps {
    label?: ReactNode;
    /** Where the label sits relative to the field. */
    labelPosition?: 'top' | 'left';
    /** Label column width in px when labelPosition is 'left' — share one value across stacked fields so they align. */
    labelWidth?: number;
    disabled?: boolean;
    className?: string;
}
export declare const fieldCls = "w-full min-w-0 border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-200 placeholder-slate-500 outline-none transition-colors hover:border-slate-600 focus:border-blue-400 disabled:cursor-not-allowed disabled:opacity-50";
/** Select-style popover trigger chrome shared by the picker fields. */
export declare function pickerTriggerCls(open: boolean, disabled: boolean): string;
/** Body-portaled popover container shared by the picker fields (matches the
 *  Select list's box). */
export declare const pickerPopCls = "fixed z-[1000] border border-slate-700 bg-slate-900 text-slate-200 text-xs shadow-black/40 shadow-lg";
/** Optional top/left label wrapper shared by the text fields. */
export declare function Labelled({ label, labelPosition, labelWidth, multiline, className, children, }: LabelledProps & {
    multiline?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
