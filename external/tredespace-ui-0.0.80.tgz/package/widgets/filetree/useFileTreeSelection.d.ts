import { type TreeRow } from './fileTreeModel';
/**
 * Desktop-file-manager selection: click = select one, Ctrl+click = toggle,
 * Shift+click = range over the VISIBLE rows; a folder row selects/toggles its
 * whole subtree.
 */
export declare function useFileTreeSelection(selected: Set<string>, onSelect: (next: Set<string>) => void, visibleFiles: string[]): {
    click: (row: TreeRow, e: React.MouseEvent) => void;
};
