import { useCallback, useEffect, useRef, useState } from 'react';
/**
 * The stepper's interaction engine: clamped commits, non-passive wheel
 * stepping, and Blender-style horizontal "rolling" (press + drag while
 * unfocused; a plain click focuses for typing instead).
 */
export function useNumberInputControl(value, onChange, step, decimals, min, max, disabled) {
    const clamp = useCallback((v) => {
        const c = Math.min(max ?? Infinity, Math.max(min ?? -Infinity, v));
        return +c.toFixed(decimals);
    }, [min, max, decimals]);
    const [text, setText] = useState(null); // non-null while editing
    const inputRef = useRef(null);
    const drag = useRef(null);
    const latest = useRef({ value, onChange, disabled });
    latest.current = { value, onChange, disabled };
    const commitText = () => {
        if (text != null) {
            const v = parseFloat(text.replace(',', '.'));
            if (!Number.isNaN(v)) {
                onChange(clamp(v));
            }
        }
        setText(null);
    };
    // Wheel must be non-passive to stop the panel from scrolling instead.
    useEffect(() => {
        const el = inputRef.current;
        if (!el) {
            return;
        }
        const onWheel = (e) => {
            if (latest.current.disabled) {
                return;
            }
            e.preventDefault();
            latest.current.onChange(clamp(latest.current.value + (e.deltaY < 0 ? step : -step)));
        };
        el.addEventListener('wheel', onWheel, { passive: false });
        return () => el.removeEventListener('wheel', onWheel);
    }, [step, clamp]);
    const onPointerDown = (e) => {
        // Dragging while focused would fight text selection — rolling starts unfocused.
        if (disabled || document.activeElement === inputRef.current) {
            return;
        }
        // Block native focus + text selection while rolling; a plain click gets
        // focused manually on pointerup instead.
        e.preventDefault();
        drag.current = { x: e.clientX, start: value, rolled: false };
        e.currentTarget.setPointerCapture(e.pointerId);
    };
    const onPointerMove = (e) => {
        const d = drag.current;
        if (!d) {
            return;
        }
        const dx = e.clientX - d.x;
        if (!d.rolled && Math.abs(dx) < 4) {
            return;
        }
        d.rolled = true;
        e.preventDefault();
        onChange(clamp(d.start + Math.round(dx / 4) * step));
    };
    const onPointerUp = (e) => {
        const d = drag.current;
        drag.current = null;
        if (d?.rolled) {
            e.currentTarget.releasePointerCapture(e.pointerId);
            e.preventDefault();
        }
        else if (d) {
            inputRef.current?.focus(); // plain click → start editing (onFocus fills the text)
        }
    };
    const bump = (dir) => onChange(clamp(value + dir * step));
    return {
        text,
        setText,
        commitText,
        bump,
        inputRef,
        isDragging: () => drag.current != null,
        onPointerDown,
        onPointerMove,
        onPointerUp,
    };
}
