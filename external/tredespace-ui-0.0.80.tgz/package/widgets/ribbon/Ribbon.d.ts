import { type ReactNode } from 'react';
export { RibbonButton, type RibbonButtonProps } from './RibbonButton';
export { RibbonNumber, type RibbonNumberProps } from './RibbonNumber';
export { RibbonSlot } from './RibbonSlot';
export type { RibbonSize } from './ribbonSizes';
/** The bar itself: a full-height row of sections with dividers between them. */
export declare function Ribbon({ children, className }: {
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
/**
 * A titled group: the item area on top, a full-width title bar underneath.
 * Children declare a `size` (big = 1 per column, medium = 2, mini = 3); the
 * section packs them into equal-width columns in order, and a column that is
 * not completely full centres its content vertically.
 */
export declare function RibbonSection({ title, children, className, }: {
    title: ReactNode;
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
