import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Children, isValidElement } from 'react';
import { RIBBON_ROWS } from './ribbonSizes';
export { RibbonButton } from './RibbonButton';
export { RibbonNumber } from './RibbonNumber';
export { RibbonSlot } from './RibbonSlot';
/** The bar itself: a full-height row of sections with dividers between them. */
export function Ribbon({ children, className = '' }) {
    return (_jsx("div", { className: `flex h-full min-w-0 items-stretch overflow-x-auto bg-slate-900 px-1 py-1 ${className}`, children: children }));
}
/**
 * A titled group: the item area on top, a full-width title bar underneath.
 * Children declare a `size` (big = 1 per column, medium = 2, mini = 3); the
 * section packs them into equal-width columns in order, and a column that is
 * not completely full centres its content vertically.
 */
export function RibbonSection({ title, children, className = '', }) {
    const columns = [];
    let column = [];
    let used = 0;
    for (const child of Children.toArray(children)) {
        const size = (isValidElement(child) && child.props.size) || 'big';
        if (used + RIBBON_ROWS[size] > 6) {
            columns.push(column);
            column = [];
            used = 0;
        }
        column.push(child);
        used += RIBBON_ROWS[size];
    }
    if (column.length) {
        columns.push(column);
    }
    return (_jsxs("div", { className: `grid shrink-0 grid-rows-[1fr_auto] gap-y-1 border-slate-800 border-r px-1.5 last:border-r-0 ${className}`, children: [_jsx("div", { className: "grid min-h-0 auto-cols-max grid-flow-col gap-x-0.5", children: columns.map((col, i) => (_jsx("div", { className: "flex min-h-0 flex-col justify-center gap-[2px]", children: col }, i))) }), _jsx("div", { className: "w-full px-3 py-0.5 text-center text-slate-400 text-xs leading-tight", children: title })] }));
}
