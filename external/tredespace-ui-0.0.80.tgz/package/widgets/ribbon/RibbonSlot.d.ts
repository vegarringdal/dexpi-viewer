import type { ReactNode } from 'react';
import { type RibbonSize } from './ribbonSizes';
/**
 * Puts any content into the ribbon's sizing system — the escape hatch for
 * inputs, selects, whatever. The content is vertically centred in its slot.
 */
export declare function RibbonSlot({ size, children, className, }: {
    size?: RibbonSize;
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
