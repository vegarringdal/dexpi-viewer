export type RibbonSize = 'big' | 'medium' | 'mini';
export declare const RIBBON_ROWS: Record<RibbonSize, number>;
export declare const RIBBON_HEIGHT: Record<RibbonSize, string>;
