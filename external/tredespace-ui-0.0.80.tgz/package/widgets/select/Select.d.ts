export interface SelectOption {
    value: string;
    label: string;
    /** Dimmed text after the label — a unit, a path, a shortcut. */
    hint?: string;
    disabled?: boolean;
}
interface BaseProps {
    options?: SelectOption[];
    placeholder?: string;
    /** Show a filter box at the top of the list. Implied by loadOptions. */
    searchable?: boolean;
    /**
     * Async search: called (debounced) with the current query; resolve with the
     * matching options or throw/reject to show the error in the list. Replaces
     * local filtering of `options`.
     */
    loadOptions?: (query: string) => Promise<SelectOption[]>;
    disabled?: boolean;
    className?: string;
}
export interface SingleSelectProps extends BaseProps {
    multiple?: false;
    value: string | null;
    /** Receives null when the user clears the selection. */
    onChange: (value: string | null) => void;
}
export interface MultiSelectProps extends BaseProps {
    multiple: true;
    value: string[];
    onChange: (value: string[]) => void;
}
export type SelectProps = SingleSelectProps | MultiSelectProps;
/**
 * A dropdown in the dock's visual language. Single or multi select, optional
 * search, full keyboard support (arrows / Enter / Escape / type-to-filter).
 * Multi-select keeps the list open and shows checkmarks; the trigger sums up.
 */
export declare function Select(props: SelectProps): import("react").JSX.Element;
export {};
