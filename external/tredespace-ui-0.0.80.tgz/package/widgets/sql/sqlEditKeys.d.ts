export declare const INDENT = "  ";
/** One edit: replace [replaceStart, replaceEnd) with `text`, then select
 *  [selStart, selEnd). */
export interface TextEdit {
    replaceStart: number;
    replaceEnd: number;
    text: string;
    selStart: number;
    selEnd: number;
}
/** Tab: multi-line selection → indent every non-empty touched line and keep
 *  those lines selected; otherwise insert one indent at the caret (replacing
 *  a single-line selection). */
export declare function indentSelection(value: string, start: number, end: number): TextEdit;
/** Shift+Tab: remove up to one indent (or a leading tab) from every touched
 *  line. With a caret the line is outdented in place and the caret shifts
 *  left by what was removed; a selection ends up covering the whole lines.
 *  Returns null when nothing can be removed. */
export declare function outdentSelection(value: string, start: number, end: number): TextEdit | null;
/** Enter: newline plus the current line's leading whitespace (auto-indent),
 *  replacing any selection. */
export declare function newlineKeepIndent(value: string, start: number, end: number): TextEdit;
