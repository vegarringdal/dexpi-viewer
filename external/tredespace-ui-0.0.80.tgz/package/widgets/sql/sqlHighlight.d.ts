export declare const EDITOR_TEXT = "font-mono text-[12px] leading-[18px] whitespace-pre-wrap break-words";
/** SQL → highlighted spans. Anything unmatched stays plain text. */
export declare function highlightSql(sql: string): React.ReactNode[];
