import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { ClearButton, fieldCls, Labelled } from '../fieldChrome';
/** Single-line text field in the studio look, label on top or to the left. */
export function TextInput({ value, onChange, onCommit, placeholder, type = 'text', maxLength, spellCheck = false, clearable = true, onClear, disabled = false, ...labelled }) {
    const showClear = clearable && !disabled && (onClear != null || value.length > 0);
    return (_jsx(Labelled, { ...labelled, disabled: disabled, children: _jsxs("div", { className: "relative", children: [_jsx("input", { type: type, value: value, placeholder: placeholder, maxLength: maxLength, spellCheck: spellCheck, disabled: disabled, className: `${fieldCls} h-6 py-0 ${showClear ? 'pr-6' : ''}`, onChange: (e) => onChange(e.target.value), onBlur: (e) => onCommit?.(e.target.value), onKeyDown: (e) => {
                        if (e.key === 'Enter') {
                            onCommit?.(e.target.value);
                        }
                    } }), showClear && (_jsx(ClearButton, { className: "top-1/2 right-0.5 -translate-y-1/2", onClick: () => (onClear ? onClear() : onChange('')) }))] }) }));
}
