import { type Time } from './timeMath';
/** Which dial the popover is editing: an endpoint's hour or minute. */
export type TimeStage = Readonly<{
    endpoint: 'start' | 'end';
    mode: 'hour' | 'minute';
}>;
export interface TimeDigitsProps {
    start: Time;
    /** Second endpoint — null renders the single-time header. */
    end: Time | null;
    stage: TimeStage;
    onStage: (stage: TimeStage) => void;
}
/** The popover's segmented HH:MM header (one or two endpoints); each digit
 *  pair is a button that switches the dial to that endpoint + mode. */
export declare function TimeDigits({ start, end, stage, onStage }: TimeDigitsProps): import("react").JSX.Element;
