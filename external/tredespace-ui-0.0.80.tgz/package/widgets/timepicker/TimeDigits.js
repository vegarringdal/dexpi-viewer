import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../../lib/cn';
import { formatTime } from './timeMath';
const DIGIT_CLS = 'cursor-pointer px-1 py-0.5 font-mono text-lg leading-none';
/** The popover's segmented HH:MM header (one or two endpoints); each digit
 *  pair is a button that switches the dial to that endpoint + mode. */
export function TimeDigits({ start, end, stage, onStage }) {
    const segment = (endpoint, t) => {
        const digit = (mode) => (_jsx("button", { type: "button", "data-tooltip": `Pick ${endpoint === 'end' && end != null ? 'end ' : end != null ? 'start ' : ''}${mode}`, className: cn(DIGIT_CLS, stage.endpoint === endpoint && stage.mode === mode
                ? 'bg-blue-950 text-blue-100'
                : 'text-slate-400 hover:text-slate-200'), onClick: () => onStage({ endpoint, mode }), children: formatTime(t).slice(mode === 'hour' ? 0 : 3, mode === 'hour' ? 2 : 5) }));
        return (_jsxs("span", { className: "flex items-center", children: [digit('hour'), _jsx("span", { className: "font-mono text-lg text-slate-500 leading-none", children: ":" }), digit('minute')] }, endpoint));
    };
    return (_jsxs("div", { className: "flex items-center justify-center gap-0.5 border-slate-700 border-b p-1.5", children: [segment('start', start), end != null && _jsx("span", { className: "px-1 text-slate-500", children: "\u2013" }), end != null && segment('end', end)] }));
}
