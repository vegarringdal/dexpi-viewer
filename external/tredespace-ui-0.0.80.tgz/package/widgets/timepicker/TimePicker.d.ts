/** A time span; either edge may still be unset while the user is picking.
 *  End before start is legal and means the range crosses midnight. */
export type TimeRange = Readonly<{
    start: string | null;
    end: string | null;
}>;
interface TimePickerBaseProps {
    /** Snap picked minutes to this step (default 1 = exact minute). */
    minuteStep?: number;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    /** Styled tooltip (data-tooltip) on the field. */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
}
export interface SingleTimePickerProps extends TimePickerBaseProps {
    range?: false;
    /** Selected time as 24-hour `"HH:MM"`, or null when empty. */
    value: string | null;
    /** Receives the picked time (`"HH:MM"`), or null when cleared. */
    onChange: (value: string | null) => void;
}
export interface RangeTimePickerProps extends TimePickerBaseProps {
    /** Range mode: the flow runs start hour → start minute → end hour → end
     *  minute; the header digits re-edit any part. No ordering is enforced —
     *  an end before the start is an overnight range. */
    range: true;
    value: TimeRange;
    onChange: (value: TimeRange) => void;
}
export type TimePickerProps = SingleTimePickerProps | RangeTimePickerProps;
/**
 * A compact 24-hour time field with an Android-style analog clock popover:
 * dual-ring hour dial (1–12 outer, 00/13–23 inner), auto-advancing to the
 * minute dial; range mode chains a second endpoint. Values cross the API as
 * `"HH:MM"` strings.
 */
export declare function TimePicker(props: TimePickerProps): import("react").JSX.Element;
export {};
