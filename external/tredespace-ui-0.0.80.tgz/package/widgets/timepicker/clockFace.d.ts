export interface ClockDialProps {
    mode: 'hour' | 'minute';
    hour: number;
    minute: number;
    /** Snap picked minutes to this step (1 = exact). */
    minuteStep: number;
    onPick: (mode: 'hour' | 'minute', value: number) => void;
    /** Pointer released / value clicked — the picker advances hour→minute→done. */
    onCommit: () => void;
}
/** The analog dial of TimePicker: drag or click to pick; hours use the
 *  Android 24-hour dual ring, minutes a single ring with 5-minute labels. */
export declare function ClockDial({ mode, hour, minute, minuteStep, onPick, onCommit }: ClockDialProps): import("react").JSX.Element;
