export type Time = Readonly<{
    h: number;
    m: number;
}>;
/** Parse `"HH:MM"` (24 h); null when malformed or out of range. */
export declare function parseTime(value: string | null | undefined): Time | null;
export declare function formatTime(t: Time): string;
/** The current local time (the one place local time is read). */
export declare function nowTime(): Time;
