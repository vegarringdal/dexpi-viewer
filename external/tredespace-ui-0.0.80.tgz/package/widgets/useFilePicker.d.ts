import { type ReactNode } from 'react';
/** A hidden `<input type=file>` + an `open()` trigger — the shared piece of
 *  every panel's Load… button. Render `element` anywhere in the tree. */
export declare function useFilePicker(accept: string, onFile: (file: File) => void): {
    element: ReactNode;
    open: () => void;
    ref: React.RefObject<HTMLInputElement | null>;
};
/** Same as useFilePicker, but the user can pick SEVERAL files at once (SQL
 *  Assets → Import Database). `onFiles` never gets an empty list. */
export declare function useMultiFilePicker(accept: string, onFiles: (files: File[]) => void): {
    element: ReactNode;
    open: () => void;
    ref: React.RefObject<HTMLInputElement | null>;
};
/** Read a picked file as text and hand it to `onText`; parse errors are the
 *  caller's job (they usually show a dialog). */
export declare function readFileText(file: File, onText: (text: string) => void): void;
